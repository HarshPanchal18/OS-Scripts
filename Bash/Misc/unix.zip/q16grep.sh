#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Wednesday 31 August 2022 11:21:00 AM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

#a. count number of blank lines in f1.txt
grep -c '^$' f1.txt
grep -cv -P '\S' f1.txt
<<Explanation
-P '\S' – This selects all lines that have a non whitespace character
-c – Print the count of matching lines
-v – Select only the non-matching lines

So, we are first matching all lines that have a non whitespace character and then use -v option to ignore them and then -c option to print the count instead of the actual line.
If we wanted the count of all non-empty lines, then we just have to remove the -v option from the above command.
Explanation
grep -c -P '\S' f1.txt

#b. print all line containig sdjic
grep 'sdjic' f1.txt

#c. print lines that starting with sdjic
grep '^sdjic' f1.txt

#d. Search the files in CPROGRAMS directory which has the string 'include'
grep -rnw CPROGRAMS -e 'include'

<<exp
    -r or -R is recursive,
    -n is line number, and
    -w stands for match the whole word.
    -l (lower-case L) can be added to just give the file name of matching files.
    -e is the pattern used during the search

Along with these, --exclude, --include, --exclude-dir flags could be used for efficient searching:

This will only search through those files which have .c or .h extensions:
grep --include=\*.{c,h} -rnw '/path/to/somewhere/' -e "pattern"

This will exclude searching all the files ending with .o extension:
grep --exclude=\*.o -rnw '/path/to/somewhere/' -e "pattern"

For directories it's possible to exclude one or more directories using the --exclude-dir parameter. For example, this will exclude the dirs dir1/, dir2/ and all of them matching *.dst/:
grep --exclude-dir={dir1,dir2,*.dst} -rnw '/path/to/somewhere/' -e "pattern"


Use grep -ilR:

grep -Ril "text-to-find-here" /

    i stands for ignore case (optional in your case).
    R stands for recursive.
    l stands for "show the file name, not the result itself".
    / stands for starting at the root of your machine.
exp

#e. print lines having exactly 50 characters in f1.txt
grep -c -E "^.{3}$" input.txt

#This will count (-c) the number of lines which match the regex (-E) "^.{3}$", which is "start of line, exactly three of anything, end of line"

#awk '{if(length($0) == 3) print}' file

#f. count number of blank lines in f1.txt
grep -c '^$' f1.txt

#g. Display lines having atleast one characters in f1.txt
grep -v '^$' f1.txt

#h. print lines that having sdjic in any case
grep -i 'sdjic' f1.txt

#i. display line of f1.txt having exactly 3 characters
grep -cE "^.{3}$" f1.txt

#j. display lines of f1.txt which begin with any alphabet
grep -v '^[^[:alpha:]]' f1.txt

#k. display lines whose last word is "UNIX" in f1.txt
grep 'UNIX$' f1.txt

#l. display lines having last characters as digits [0-9]
grep '[0-9]$' f1.txt

#m. display list of filenames that only consist digits
ls | grep -E '^[0-9]+$'

#n. display the lines of f1.txt which only consist digits
grep -E '^[0-9]+$' f1.txt

#o. display the lines of f1.txt which only consist capital characters
grep -E '^[A-Z]+$' f1.txt

#p. search all lines of f1.txt which ends with "."
grep '\.$' f1.txt
