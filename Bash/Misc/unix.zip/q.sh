w=($(awk '{print NF }' $1))
c=($(awk '{print length }' $1))

CNT=0; while read -r LINE; do (( CNT++ )); done < $1
echo Lines: $CNT

for i in ${w[@]}; do
    sum=`expr $sum + $i`
done

echo Words: $sum

for i in ${c[@]};do
    sum=`expr $sum + $i`
done

echo Characters: $sum



<<comm
echo (awk 'END{print NR}' $1)
sed -n '$=' $1

CNT=0; while read -r LINE; do (( CNT++ )); done < $1; echo $CNT
CNT=0; while read -r ; do (( CNT++ )); done < $1; echo $CNT

while read LINE
do
    len=${#LINE}
    echo "Line length is : $len"
done

while read -n1 c; do
    echo "$c"
done
comm
while IFS= read -r line;do echo $line; done
w=$(awk '{print NF }' $1)
c=$(awk '{print length }' $1)
echo Words
echo $w
echo Chars
echo $c


grep '^a.*e$' file

#This means: look for those lines starting (^) with a, then 0 or more characters and finally and e at the end of the line ($).
