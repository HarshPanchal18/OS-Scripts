#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 06:27:52 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

read -p "Enter a ending number: " end
i=2
while [ $i -le $end ]
do
    flag=1
    j=2
    while [ $j -lt $i ]
    do
	rem=$(( $i % $j ))
	if [ $rem -eq 0 ]
	then
	    flag=0
	    break
	fi
	((j++))
    done
    [ $flag -eq 1 ] && printf '%d\t' $i
    ((i++))
done
