read -p "Enter a number: " n
sd=0 # store single digit

sum=0 # store number of digit

# use while loop to calculate the sum of all digits
while [ $n -gt 0 ]
do
    sd=$(( $n % 10 )) # get Remainder
    n=$(( $n / 10 ))  # get next digit
    sum=$(( $sum + $sd )) # calculate sum of digit
done

echo  "Sum of digit is $sum"
