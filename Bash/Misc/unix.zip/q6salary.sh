#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Monday 12 September 2022 08:15:30 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

read -p "Enter Basic Amount: " sal

echo "
a) Dearness allowance (90% of basic)
b) Provident Fund (12% of basic)
c) House Rent Allowance (20% of basic + DA)
d) Income Tax Deducted (5% of basic + DA + HRA)
e) Take Home Salary (basic + DA + HRA - IT)
"
read -p "Enter choice: " ch

da=$(((`expr $sal \* 9 / 10`)))
pf=$(((`expr $sal \* 12 / 100`)))
hra=$(((`expr $sal \* 2 / 10`)+$da))
it=$(((`expr $sal \* 5 / 100`)+$da+$hra))
final=$(($sal+$da+$hra-$it))

case $ch in
    a)
	echo $da
	;;
    b)
	echo $pf
	;;
    c)
	echo $hra
	;;
    d)
	echo $it
	;;
    e)
	echo $final
	;;
    *)echo Invalid Choice
	;;
esac
