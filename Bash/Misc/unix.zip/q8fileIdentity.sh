#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 07:10:03 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

read -p "Enter two file names separaterd by space: " file1 file2

if cmp -s $file1 $file2
then
   echo "The files have same contents"
   exit 0
fi
echo "The files have different contents"
