#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Wednesday 24 August 2022 09:40:04 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

read -p "Enter a number: " n

x=0; y=1; i=2;
echo -n "$x $y "
while [ $i -lt $n ]; do
    i=$((i + 1))
    z=$((x + y))
    echo -n "$z "
    x=$y
    y=$z
    sleep .5
done
