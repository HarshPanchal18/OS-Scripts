#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 09:25:30 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

read -rp "Who are you checking on? " $REPLY

if w -h | grep -q "^$REPLY "; then
    echo "$REPLY is logged in."
else
    echo "$REPLY is not logged in."
fi
echo

<<comm
read -p "Who are you? " user &&
    ((    # prompt for username, save as $user
    who -u | grep -q "^$user "   &&       # test if user is logged in
    top -u "$user"                  ) || # run top with that username
    echo "$user is not logged in"
	))     # error message
comm

read -p "Enter Username: " check
user="$(id -u -n)"

[ "$check" = "$user" ] && echo "$check Is Logged In"|| echo "$check Is Not Logged In"
