#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 07:37:23 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage: ./countCWL.sh [file]
#------------------------------------------
read -p "Enter a Filename: " file

w=($(awk '{print NF }' $file))
c=($(awk '{print length }' $file))

line=0; while read -r LINE; do (( line++ )); done < $file
echo Lines: $line

for i in ${w[@]}; do sum=`expr $sum + $i`; done
echo Words: $sum

for i in ${c[@]};do sum=`expr $sum + $i`; done
echo Characters: $sum
