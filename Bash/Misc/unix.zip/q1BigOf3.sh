#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 06:22:23 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

read -p "Enter 3 numbers: " a b c
echo -n "Biggest is: "
#[ $a -ge $b ] && [ $a -ge $c ] && echo $a || [ $b -ge $c ] && echo $b || echo $c

if [[ $a -ge $b ]] && [[  $a -ge $c ]]
then
    echo $a
elif [[ $b -ge $c ]]
then
    echo $b
else
    echo $c
fi
