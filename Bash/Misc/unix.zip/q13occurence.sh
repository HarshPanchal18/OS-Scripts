#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 09:42:31 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

if [ $# -lt 1 ]
then
    echo Please provide inputfile
    exit 1
fi
grep -o 'SDJIC' $1 | wc -l
