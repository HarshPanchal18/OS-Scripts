#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Wednesday 31 August 2022 11:37:34 AM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

#a. to print only last line of f1.txt
sed -n '$p' f1.txt
sed '$!d' file
#!/bin/bash

while read line
do
        x=$line
done < file
echo $x

#b. to print line numbers 1-3, 6-7 and 10 of f1.txt
sed -n ‘1~2’p filename

#c. to print lines begining with SDJIC of f1.txt
sed -n '/echo/p' f1.txt

#d. print three lines starting from fourth line of f1.txt
sed -n '4,6p' f1.txt

#e. print all blank lines of f1.txt
#to delete all empty lines from a file called /tmp/data.txt, enter:
sed '/^$/d' /tmp/data.txt
sed '/^[[:space:]]*$/d' input.file
sed -i '/^[[:space:]]*$/d' input.file
sed -r '/^\s*$/d' input.file > output.file
sed -i '/^[[:space:]]*$/d' /tmp/data.txt

#f. print lines having "sdjic" or "sdjyc"
sed -n '/sdjic$/p;/sdjyc$/p' f1.txt

#g. lines begining with either alphabet or digit
sed -n '/[a-zA-Z0-9]/p' f1.txt

#h. to insert a line "additional line" before every line
sed 's/^/additional line\n/' f1.txt

#i. to replace every occurence of | with : of first three lines
sed '1,3s/|/:/g'

#j. to replace every occurence of | with : of every line
sed 's/|/:/g'

#k. remove all lines having word "fail" from f1.txt (delete command)
sed '/file/d' f1.txt
