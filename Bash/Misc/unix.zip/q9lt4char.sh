#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 07:18:02 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

echo "Words having Lengths of One"
tr ' ' '\n' < $1 | grep '^.\{1\}$' | uniq

echo "Words having Lengths of Two"
tr ' ' '\n' < $1 | grep '^.\{2\}$' | uniq

echo "Words having Lengths of Three"
tr ' ' '\n' < $1 | grep '^.\{3\}$' | uniq

echo "Words having Lengths of Four"
tr ' ' '\n' < $1 | grep '^.\{4\}$' | uniq
