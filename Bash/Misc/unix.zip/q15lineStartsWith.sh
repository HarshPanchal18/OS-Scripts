#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 10:00:18 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

#read -p "Enter Filename and Pattern: " file str

grep -i '^unix' 11.txt
#sed -n "/^$str/p" $file
#awk "/^$str/{print}" $file
#grep '^foo$' $file
