#!/bin/bash

#------------------------------------------
# Purpose:
# Created Date:  Tuesday 30 August 2022 09:49:20 PM IST
# © Author: Harsh Panchal

# Modify this script for your own purposes.

# Usage:
#------------------------------------------

# Shell script to reverse the Input String

#echo " **** Program to Reverse a String **** "
function resStr()
{
    read -p " Enter Here : " text
    echo -n "Reverse of String : "

    rev=""
    len="${#text}"
    i=0
    while (($i<len))
    do
	rev="${text:i++:1}$rev"
    done
    echo $rev
}



read -p " Enter Filename : " file
txts=`tac $file`

revs=""
len="${#txts}"
i=0
while (($i<len))
do
    revs="${txts:i++:1}$revs"
done
echo $revs


#---------
#arr=($text)

#arrlength=${#arr[@]}
#arrlength=${#text}

#i=$((arrlength - 1))

#while [[ $i -ge 0 ]]
#do

#    rev="$rev${str:$i:1}"
#    echo -n ${text[arrlength]}
#    echo -n " "
    #arrlength=`expr $arrlength - 1`
    #i=`expr $i-1`
 #   i=$((i-1))
#done
#echo $rev

#str='test a is this'; res=""; prev=""
#while [ "$prev" != "$str" ]; do res="$res${str##* } "; prev="$str"; str="${str% *}"; done
#echo $str
